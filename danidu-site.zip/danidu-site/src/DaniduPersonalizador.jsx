import { useState } from "react";

const fonts = ["Arial", "Courier New", "Georgia", "Times New Roman", "Verdana"];
const colors = ["black", "red", "blue", "green", "purple"];
const sizes = [
  { label: "10 cm", value: 10, price: 3 },
  { label: "15 cm", value: 15, price: 4 },
  { label: "20 cm", value: 20, price: 5 },
];

export default function DaniduPersonalizador() {
  const [nome, setNome] = useState("");
  const [fonte, setFonte] = useState(fonts[0]);
  const [cor, setCor] = useState(colors[0]);
  const [tamanho, setTamanho] = useState(sizes[0]);

  const precoTotal = nome.length * tamanho.price;

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold mb-4 text-center">Danidu - Letras em Madeira Personalizadas</h1>

      <div className="mb-4 space-y-4">
        <input
          className="w-full border rounded p-2"
          placeholder="Escreve o nome aqui..."
          value={nome}
          onChange={(e) => setNome(e.target.value)}
        />

        <div>
          <label className="block font-medium mb-1">Tipo de letra:</label>
          <div className="flex gap-2 flex-wrap">
            {fonts.map((f) => (
              <button
                key={f}
                onClick={() => setFonte(f)}
                className={\`px-3 py-1 border rounded \${fonte === f ? 'bg-gray-200' : ''}\`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block font-medium mb-1">Cor:</label>
          <div className="flex gap-2 flex-wrap">
            {colors.map((c) => (
              <button
                key={c}
                onClick={() => setCor(c)}
                className="w-6 h-6 rounded-full border"
                style={{ backgroundColor: c, outline: cor === c ? '2px solid gray' : 'none' }}
              ></button>
            ))}
          </div>
        </div>

        <div>
          <label className="block font-medium mb-1">Tamanho:</label>
          <div className="flex gap-2">
            {sizes.map((s) => (
              <button
                key={s.label}
                onClick={() => setTamanho(s)}
                className={\`px-3 py-1 border rounded \${tamanho.label === s.label ? 'bg-gray-200' : ''}\`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        <div className="mt-4 border p-4 rounded bg-gray-50 text-center">
          <p className="text-lg" style={{ fontFamily: fonte, color: cor }}>
            {nome || "Pré-visualização aqui"}
          </p>
        </div>

        <p className="text-right font-bold">Preço: {precoTotal.toFixed(2)} €</p>

        <button className="w-full bg-black text-white py-2 rounded">Adicionar ao Carrinho</button>
      </div>
    </div>
  );
}